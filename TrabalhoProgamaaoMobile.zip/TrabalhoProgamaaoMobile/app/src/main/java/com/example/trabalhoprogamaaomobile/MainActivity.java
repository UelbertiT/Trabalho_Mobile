package com.example.trabalhoprogamaaomobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btCadastroCliente;
    private Button btCadastroItensVenda;
    private Button btLançamentoPedido;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btCadastroCliente = findViewById(R.id.btCadastroCliente);
        btCadastroCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirAcitivity(CadastroClienteActivity.class);
            }
        });
        btCadastroItensVenda = findViewById(R.id.btCadastroItensVenda);
        btCadastroItensVenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { abrirAcitivity(CadastroItenVendaActivity.class);}
        });
        btLançamentoPedido = findViewById(R.id.btLançamentoPedido);
        btLançamentoPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { abrirAcitivity(LancarPedidoActivity.class);}
        });
    }

    private void abrirAcitivity(Class<?> activity){
        Intent intent = new Intent(MainActivity.this, activity);
        startActivity(intent);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }
}