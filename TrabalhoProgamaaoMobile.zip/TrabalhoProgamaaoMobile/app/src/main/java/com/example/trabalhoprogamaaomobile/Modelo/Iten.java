package com.example.trabalhoprogamaaomobile.Modelo;

public class Iten {

    private int codigo;
    private String descricao;
    private String valorUni;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getValorUni() {
        return valorUni;
    }

    public void setValorUni(String valorUni) {
        this.valorUni = valorUni;
    }
}
