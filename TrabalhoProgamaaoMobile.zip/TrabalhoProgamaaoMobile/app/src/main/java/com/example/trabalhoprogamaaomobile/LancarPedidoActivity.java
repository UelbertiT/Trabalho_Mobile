package com.example.trabalhoprogamaaomobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class LancarPedidoActivity extends AppCompatActivity {


    private Spinner spCliente, spIten;
    private EditText edQuantidade,edValorUnitario ,edQuantParcelas ;
    private Button btAddIten, btConcluirPedido;
    private RadioGroup rgCondPagamento;
    private RadioButton rbAvista, rbAprazo;
    private ListView listaItens, listaParcelas;
    private TextView tvValorTotal;
    private ArrayList<String> itensAdicionados;
    private ArrayAdapter<String> itensAdapter;
    private ArrayList<Double> parcelas;
    private ArrayAdapter<Double> parcelasAdapter;

    private double valorTotal = 0.0;
    private boolean isAVista = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lancar_pedido);

        // Inicialização de componentes
        spCliente = findViewById(R.id.spCliente);
        spIten = findViewById(R.id.spIten);
        edQuantidade = findViewById(R.id.edQuantidade);
        edValorUnitario = findViewById(R.id.edValorUnitario);
        edQuantParcelas = findViewById(R.id.edQuantParcelas);
        btAddIten = findViewById(R.id.btAddIten);
        btConcluirPedido = findViewById(R.id.btConcluirPedido);
        rgCondPagamento = findViewById(R.id.rgCondPagamento);
        rbAvista = findViewById(R.id.rbAvista);
        rbAprazo = findViewById(R.id.rbAprazo);
        listaItens = findViewById(R.id.listaItens);
        listaParcelas = findViewById(R.id.listaParcelas);
        tvValorTotal = findViewById(R.id.tvValorTotal);


        itensAdicionados = new ArrayList<>();
        itensAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itensAdicionados);
        listaItens.setAdapter(itensAdapter);

        parcelas = new ArrayList<>();
        parcelasAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, parcelas);
        listaParcelas.setAdapter(parcelasAdapter);

        ArrayAdapter<String> clienteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Cliente 1", "Cliente 2"});
        clienteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCliente.setAdapter(clienteAdapter);

        ArrayAdapter<String> itemAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Item 1", "Item 2"});
        itemAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spIten.setAdapter(itemAdapter);


        btAddIten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adicionarItem();
            }
        });

        btConcluirPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                concluirPedido();
            }
        });

        rgCondPagamento.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbAvista) {
                    isAVista = true;
                    edQuantParcelas.setVisibility(View.GONE);
                    listaParcelas.setVisibility(View.GONE);
                } else if (checkedId == R.id.rbAprazo) {
                    isAVista = false;
                    edQuantParcelas.setVisibility(View.VISIBLE);
                    listaParcelas.setVisibility(View.VISIBLE);
                }
                atualizarValorTotal();
            }
        });
    }

    private void adicionarItem() {
        String item = spIten.getSelectedItem().toString();
        String quantidadeStr = edQuantidade.getText().toString();
        String valorUnitarioStr = edValorUnitario.getText().toString();

        if (quantidadeStr.isEmpty() || valorUnitarioStr.isEmpty()) {
            Toast.makeText(this, "Preencha a quantidade e o valor unitário", Toast.LENGTH_SHORT).show();
            return;
        }

        double quantidade = Double.parseDouble(quantidadeStr);
        double valorUnitario = Double.parseDouble(valorUnitarioStr);
        double subtotal = quantidade * valorUnitario;
        itensAdicionados.add(item + " - " + quantidade + " x " + valorUnitario + " = R$ " + subtotal);
        itensAdapter.notifyDataSetChanged();

        valorTotal += subtotal;
        atualizarValorTotal();
    }

    private void atualizarValorTotal() {
        if (isAVista) {
            tvValorTotal.setText("Valor Total: R$ " + (valorTotal - (valorTotal * 0.05)));
        } else {
            int parcelas = Integer.parseInt(edQuantParcelas.getText().toString());
            double valorParcela = (valorTotal * 1.05) / parcelas;
            tvValorTotal.setText("Valor Total: R$ " + (valorTotal * 1.05));
            atualizarParcelas(parcelas, valorParcela);
        }
    }

    private void atualizarParcelas(int quantidadeParcelas, double valorParcela) {
        parcelas.clear();
        for (int i = 1; i <= quantidadeParcelas; i++) {
            parcelas.add(valorParcela);
        }
        parcelasAdapter.notifyDataSetChanged();
    }

    private void concluirPedido() {
        Toast.makeText(this, "Pedido de venda cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
    }
}