package com.example.trabalhoprogamaaomobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalhoprogamaaomobile.Modelo.Cliente;

import java.util.ArrayList;

public class CadastroClienteActivity extends AppCompatActivity {

    private Button btSalvarCliente;
    private EditText edNomeCliente;
    private EditText edCpfCliente;
    private TextView tvListaClientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_cliente);

        tvListaClientes = findViewById(R.id.tvListaClientes);
        edNomeCliente = findViewById(R.id.edNomeCliente);
        edCpfCliente = findViewById(R.id.edCpfCliente);
        btSalvarCliente = findViewById(R.id.btSalvarCliente);
        btSalvarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { salvarCliente();}
        });
        atualizarLista();
    }
    private void salvarCliente() {

        int cp = 0;
        if (edNomeCliente.getText().toString().isEmpty()) {
            edNomeCliente.setError("O Nome do Cliente deve ser informado!");
            return;
        } else {
            try {
                cp = Integer.parseInt(edCpfCliente.getText().toString());
            } catch (Exception ex) {
                edCpfCliente.setError("Informe um Cpf válido (somente números)");
            }
        }
        Cliente cliente = new Cliente();
        cliente.setNome(edNomeCliente.getText().toString());
        cliente.setCpf(edCpfCliente.getText().toString());

        Controller.getInstance().salvarCliente(cliente);

        Toast.makeText(CadastroClienteActivity.this, "Cliente Cadastrado com Sucesso!", Toast.LENGTH_LONG).show();

        finish();
    }
    private void atualizarLista(){
        String texto = "";

        ArrayList<Cliente> lista = Controller.getInstance().retornarClientes();
        for (Cliente cliente: lista) {
            texto += "\nNome: " + cliente.getNome() + "\nCPF: " + cliente.getCpf() + "\n\n";
        }

        tvListaClientes.setText(texto);
    }
}