package com.example.trabalhoprogamaaomobile;

import com.example.trabalhoprogamaaomobile.Modelo.Cliente;

import java.util.ArrayList;

public class Controller {

    private static Controller instancia;
    private ArrayList<Cliente> listaClientes;

    public static Controller getInstance(){
        if (instancia == null) {
            return instancia = new Controller();
        } else {
            return instancia;
        }
    }

    Controller() {
        listaClientes = new ArrayList<>();
    }

    public void salvarCliente(Cliente cliente){
        listaClientes.add(cliente);
    }

    public ArrayList<Cliente> retornarClientes(){
        return listaClientes;
    }
}

