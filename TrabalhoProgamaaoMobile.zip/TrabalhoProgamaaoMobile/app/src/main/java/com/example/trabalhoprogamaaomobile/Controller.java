package com.example.trabalhoprogamaaomobile;

import com.example.trabalhoprogamaaomobile.Modelo.Cliente;
import com.example.trabalhoprogamaaomobile.Modelo.Iten;

import java.util.ArrayList;

public class Controller {

    private static Controller instancia;
    private ArrayList<Cliente> listaClientes;
    private ArrayList<Iten> listaIten;


    public static Controller getInstance(){
        if (instancia == null) {
            return instancia = new Controller();
        } else {
            return instancia;
        }
    }

    private Controller() {
        listaClientes = new ArrayList<>();
        listaIten = new ArrayList<>();

    }

    public void salvarCliente(Cliente cliente){
        listaClientes.add(cliente);
    }

    public ArrayList<Cliente> retornarClientes(){
        return listaClientes;
    }

    public void  salvarIten(Iten iten){
        listaIten.add(iten);
    }
    public ArrayList<Iten> retornarIten(){
        return listaIten;
    }

}

