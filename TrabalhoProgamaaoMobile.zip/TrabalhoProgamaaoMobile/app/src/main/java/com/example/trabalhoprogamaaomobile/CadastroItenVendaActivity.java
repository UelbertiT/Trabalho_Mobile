package com.example.trabalhoprogamaaomobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.QuickContactBadge;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalhoprogamaaomobile.Modelo.Cliente;
import com.example.trabalhoprogamaaomobile.Modelo.Iten;

import java.util.ArrayList;

public class CadastroItenVendaActivity extends AppCompatActivity {

    private Button btSalvarIten;
    private EditText edCodigo;
    private EditText edDescricao;
    private EditText edValorIten;
    private TextView tvListaIten;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_iten_venda);

        tvListaIten = findViewById(R.id.tvListaIten);
        edCodigo = findViewById(R.id.edCodigo);
        edDescricao = findViewById(R.id.edDescricao);
        edValorIten = findViewById(R.id.edValorIten);
        btSalvarIten = findViewById(R.id.btSalvarIten);
        btSalvarIten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarIten();
            }
        });
        atualizarLista();
    }

    private void salvarIten() {
        if (edCodigo.getText().toString().isEmpty()) {
            edCodigo.setError("Informe o Codigo!");
            return;
        }
        if (edDescricao.getText().toString().isEmpty()) {
            edDescricao.setError("Informe a Descrição!");
            return;
        }
        if (edValorIten.getText().toString().isEmpty()) {
            edValorIten.setError("Informe o Valor unitário do Iten !");
            return;
        }
        Iten iten = new Iten();
        iten.setCodigo(Integer.parseInt(edCodigo.getText().toString()));
        iten.setDescricao(edDescricao.getText().toString());
        iten.setValorUni(edValorIten.getText().toString());

        Controller.getInstance().salvarIten(iten);

        Toast.makeText(CadastroItenVendaActivity.this, "Iten Cadastrado com Sucesso!", Toast.LENGTH_LONG).show();

        finish();
    }

    private void atualizarLista() {
        String texto = "";

        ArrayList<Iten> lista = Controller.getInstance().retornarIten();
        for (Iten iten : lista) {
            texto += "\nCodigo: " + iten.getCodigo() + "\nDescrição: " + iten.getDescricao() + "\nValor Uni: " + iten.getValorUni() + "\n\n";
        }

        tvListaIten.setText(texto);
    }
}